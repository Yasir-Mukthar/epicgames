<?php

if (isset($_SESSION['login'])) {
    header("location: index.html");
}
$login = false;
$showEmailError = false;
$showPasswordError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'include/dbconnect.php';
    $user_email = $_POST["user_email"];
    $user_password = md5($_POST["user_password"]);

    // Check if the email exists in the database
    $emailCheckSql = "SELECT * FROM users WHERE user_email = '$user_email'";
    $emailCheckResult = mysqli_query($db_con, $emailCheckSql);
    $rows = mysqli_fetch_assoc($emailCheckResult);

    if (mysqli_num_rows($emailCheckResult) == 0) {
        $showEmailError = "incorrect email.";
    } else {
        // Check if the password matches with the email
        $passwordCheckSql = "SELECT * FROM users WHERE user_email = '$user_email' AND user_password = '$user_password'";
        $passwordCheckResult = mysqli_query($db_con, $passwordCheckSql);
        if (mysqli_num_rows($passwordCheckResult) == 0) {
            $showPasswordError = "incorrect password";
        } else {
            $login = true;
            session_start();
            $_SESSION['login'] = true;
            $_SESSION['user_dname'] = $rows['user_dname'];
            $_SESSION['user_id'] = $rows['user_id'];
            header("location: users/home.php");
        }
    }
}

?>












<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register for an Epic Games account</title>
    <link rel="stylesheet" href="./css/signup.css">
    <script src="js/siginval.js"></script>

</head>

<body>

    <div class="container">
        <div class="container-div">
            <img class="logo" src="images/epic-games-logo.png" alt="" width="50px">
            <h3>Sign in with an Epics Games account</h3>
            <form class="input-style" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" onsubmit="return validateFormSignin()">



                <input type="email" placeholder="Email Address" name="user_email" required id="demail" onblur="validateFormSignin()">
                <?php  if ($showEmailError) {
                                echo ' <span style=" color:red; transform: translateY(-17px); padding:0px; height:7px;">' . $showEmailError.  '</span> ';
                    }
                    ?>


                <input type="password" placeholder="Password" name="user_password" required id="dpassword">
                <?php  if ($showPasswordError) {
                                echo ' <span style=" color:red;  transform: translateY(-17px);
                              padding:0px; height:7px; ">' . $showPasswordError . '</span> ';
                    }
                    ?>


                <!-- policy  -->
                <div class="policy-container">
                    <div class="policy"> <input type="checkbox" id="dpolicy">
                        <p>Remember Me</p>
                    </div>
                    <div class="policy">
                        <a style="color: white;" href="#link">Forgot Your Password</a>
                    </div>
                    
                </div>
                <input class="btn" type="submit" value="LOG IN NOW">



            </form>

            <a style="color: white; padding-top: 35px;" href="#link">Privacy Policy</a> </p>
            <p style="color: rgba(255, 255, 255, 0.788); padding-top: 35px;">Don’t have an Epic Games account? <a style="color: white" href="signup.php">Sign Up</a></p>

        </div>
    </div>
</body>

</html>