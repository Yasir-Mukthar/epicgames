<?php




include "include/dbconnect.php";


$showEmailError = false;
$showDisplayNameError = false;
$noError = false;
if (isset($_POST['submit'])) {

    $user_country = $_POST['user_country'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $display_name = $_POST['display_name'];

    $email_address = $_POST['email_address'];
    $user_password = md5($_POST['user_password']);
    $news_checkbox = $_POST['news_checkbox'];
    $policy_checkbox = $_POST['policy_checkbox'];






    // Check if the password matches with the email
    $nameCheckSql = "SELECT * FROM users WHERE user_email = '$email_address' AND user_dname = '$display_name'";
    $nameCheckResult = mysqli_query($db_con, $nameCheckSql);

    if (mysqli_num_rows($nameCheckResult) > 0) {
        $showDisplayNameError = "Name is already taken.";
    } else {

        // Check if the email exists in the database
        $emailCheckSql = "SELECT * FROM users WHERE user_email = '$email_address'";
        $emailCheckResult = mysqli_query($db_con, $emailCheckSql);
        $rows = mysqli_fetch_assoc($emailCheckResult);

        if (mysqli_num_rows($emailCheckResult) > 0) {
            $showEmailError = "Enter unique email.";
        } else {

            $sqli = "INSERT INTO `users`(`user_country`, `user_fname`, `user_lname`, `user_dname`, `user_email`, `user_password`, `user_news`, `user_agree`) VALUES ('$user_country','$first_name','$last_name','$display_name','$email_address','$user_password','$news_checkbox','$policy_checkbox')";
            $result = mysqli_query($db_con, $sqli);
            $noError = "Thanks for chosing our platform. Now Sigin.";

            header("location: signin.php");
        }
    }
}










?>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register for an Epic Games account</title>
    <link rel="stylesheet" href="./css/signup.css">
    <script src="js/validation.js"></script>
    <style>
        .input-style input:invalid {
            border: 1px solid red;
        }
    </style>


</head>

<body>

    <div class="container">
        <div class="container-div">
            <img class="logo" src="images/epic-games-logo.png" alt="" width="50px">
            <h3>Sign Up</h3>
            <form class="input-style" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" id="dform" onsubmit="return validateForm()">
                <select class="options" name="user_country" id="cars">
                    <option value="Pakistan">Pakistan</option>
                    <option value="India">India</option>
                    <option value="China">China</option>
                    <option value="Turkey">Turkey</option>
                    <option value="Turkey">France</option>
                    <option value="Turkey">Germany</option>
                    <option value="Turkey">Russia</option>
                    <option value="Turkey">Iran</option>
                </select>


                <div class="name-sect"><input type="text" name="first_name" placeholder="First Name" required id="fname" onblur="validateForm()">
                    <input type="text" name="last_name" placeholder="Last Name" required id="lname" onblur="validateForm()">
                </div>
                <input type="text" name="display_name" placeholder="Display Name" required id="dname" pattern="^[a-zA-Z]+$" onblur="validateForm()">
                <?php if ($showDisplayNameError) {
                    echo ' <span style=" color:red; transform: translateY(-17px); padding:0px; height:7px;">' . $showDisplayNameError .  '</span> ';
                }
                ?>
                <input type="email" placeholder="Email Address" name="email_address" required id="demail" onblur="validateForm()">
                <?php if ($showEmailError) {
                    echo ' <span style=" color:red; transform: translateY(-17px); padding:0px; height:7px;">' . $showEmailError .  '</span> ';
                }
                ?>
                <input type="password" placeholder="Password" name="user_password" required id="dpassword" onblur="validateForm()">



                <!-- policy  -->

                <div class="policy"> <input type="checkbox" id="dnews" name="news_checkbox" value="user agreed for news">
                    <p>I would like to receive news, surveys and special offers from Epic Games.</p>
                </div>
                <div class="policy"> <input type="checkbox" id="dpolicy" name="policy_checkbox" value="user agreed for policy">
                    <p> I have read and agree to the <a style="color: white;" href="#link">terms of service</a> </p>
                </div>

                <input class="btn" id="dbtn" type="submit" value="CONTINUE" name="submit">



            </form>

            <a style="color: white; padding-top: 35px;" href="#link">Privacy Policy</a> </p>
            <p style="color: rgba(255, 255, 255, 0.788); padding-top: 35px;">Already have an Epic games account? <a style="color: white" href="signin.php">Sign in</a></p>
        </div>
    </div>

</body>

</html>