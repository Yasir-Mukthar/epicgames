<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] != true) {
    header("location: ../signin.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="180">

    <title>Epic Games Store | Download & Play PC Games, Mods, DLC & More – Ahy Games</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/18cde80192.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/fontawesome.min.css">

</head>

<body>

    <header>
        <nav class="navbar " id="move-top">
            <div class="left-nav">
                <div class="logo">

                    <img src="../images/epic-games-logo.png" alt="epic-games-logo" class="logo-img">
                </div>

                <ul class="menu-ul">
                    <li class="active store" id="one"><a href="home.php">STORE</a>

                    </li>
                    <li><a href="faq.php">FAQ</a> </li>
                    <li><a href="help.php">HELP</a></li>
                    <li><a href="unreal.php">UNREAL ENGINE</a></li>
                </ul>
            </div>
            <div class="right-nav">
                <div class="earth-logo">
                    <i class="fa-solid fa-globe"></i>
                    <ul class="languages">
                        <li><a href="">English</a></li>
                        <li><a href="">Urdu</a></li>
                        <li><a href="">French</a></li>
                        <li><a href="">Arabic</a></li>
                        <li><a href="">Portuguese</a></li>
                        <li><a href="">Dutch</a></li>
                        <li><a href="">Hindi</a></li>
                        <li><a href="">Galician</a></li>
                    </ul>
                </div>
                <div class="sign-in-btn">
                    <i class="fa-solid fa-user"></i>
                    <a href="#" class="namefield"><?php echo strtoupper($_SESSION['user_dname']); ?> </a>
                    <ul class="languages">
                        <li><a href="../include/logout.php">SIGN OUT</a></li>

                    </ul>
                </div>

                <div class="download-btn">
                    <a href="">DOWNLOAD</a>
                </div>
            </div>
        </nav>

    </header>

    <main>

        <div class="fixed-menu">
            <div class="fixed-menu-center">
                <div class="right-search">
                    <div class="right-inner">

                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input class="input" type="text" placeholder="Search store">

                    </div>
                </div>
                <div class="left-menu">
                    <ul>
                        <li class="whiteColor"><a class="whiteColor" href="">Discover</a></li>
                        <li><a href="">Browse</a></li>
                        <li><a href="">News</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="main-section">
                <div class="background-pic" id="mainInformationID">
                    <img src="https://cdn2.unrealengine.com/en-holiday-carousel-desktop-1920x1080-aeec8d991d3e.jpg" alt="full back image">
                    <div class="main-information">
                        <div class="heading ">
                            <h4>Epic Game Store</h4>
                            <h3>Holiday Sale</h3>

                        </div>
                        <span id="span">Festive savings are here!</span>
                        <div class="inner-information">
                            <p>Whether you've been naughty or nice, save up to 75% across selected Games and Add-Ons
                                until Jan 5.</p>
                        </div>
                        <div class="save-btn">
                            <a href="">Save Now</a>
                        </div>
                    </div>

                </div>
                <div class="right-detail">
                    <div class="detail-box box1" id="element1">
                        <img src="https://cdn2.unrealengine.com/en-holiday-sale-thumbnail-image-1200x1600-310a0e197f0f.jpg?h=480&resize=1&w=360" alt="">
                        <div class="image-header">
                            <h4>Epic Game Store Holiday Sale
                            </h4>
                        </div>
                    </div>
                    <div class="detail-box" id="element2">
                        <img src="https://cdn2.unrealengine.com/gen-egs-holidaysale2021-epiccoupon-carousel-thumbnail-1200x1600-v01-1200x1600-015283cb0229.jpg?h=480&resize=1&w=360" alt="">
                        <div class="image-header">
                            <h4>Epic Games Store Holiday Coupon
                            </h4>
                        </div>
                    </div>
                    <div class="detail-box" id="element3">
                        <img src="https://cdn2.unrealengine.com/en-free-offers-thumbnail-image-1200x1600-57c2eff9424c.jpg?h=480&resize=1&w=360" alt="">
                        <div class="image-header">
                            <h4>Epic Free Offers
                            </h4>
                        </div>
                    </div>
                    <div class="detail-box" id="element4">
                        <img src="https://cdn2.unrealengine.com/egs-midnight-suns-carousel-thumbnail-v2-1200x1600-f2ad382e29a2.jpg?h=480&resize=1&w=360" alt="">
                        <div class="image-header">
                            <h4>Marvel's Midnight Suns
                            </h4>
                        </div>
                    </div>
                    <div class="detail-box box-1" id="element5">
                        <img src="https://cdn2.unrealengine.com/egs-need-for-speed-unbount-palace-edition-carousel-thumb-1200x1600-49ebf4fb1204.jpg?h=480&resize=1&w=360" alt="">
                        <div class="image-header">
                            <h4>Need for Speed™ </h4>

                        </div>
                    </div>
                    <div class="detail-box box-1" id="element6">
                        <img src="https://cdn2.unrealengine.com/egs-callisto-protocol-carousel-thumb-1200x1600-a10ac9c52ec5.jpg?h=480&resize=1&w=360" alt="">
                        <div class="image-header">
                            <h4>The Callisto Protocol
                            </h4>
                        </div>
                    </div>

                </div>
            </div>






        </div>


        <div class="container">


            <!---------------------------
    
    
    sales slider html code 


-------------------------------->

            <?php
            // Read data from database
            include("../include/dbconnect.php");

            // $sql_select = "SELECT * FROM `game` WHERE 1";
            $sql_select = "SELECT g.game_id, g.game_name, g.price, g.game_description, g.publisher_id, g.developer_id, g.release_date, g.platform_id, g.rating, i.image_id, i.image_link, i.image_logo, i.image_link1, i.image_link2, i.image_link3
           FROM game g
           INNER JOIN game_categories gc ON g.game_id = gc.game_id
           INNER JOIN image i ON g.game_id = i.game_id
           WHERE gc.category_id = 3";




            // if (isset($_POST['submit'])) {

            //   $search = $_POST['search'];


            //   $sql_select = "SELECT * FROM `users` where user_id like '%$search%' or user_name like '%$search%' or user_address like '%$search%'";
            //   $search = '';
            // }

            $result_select = mysqli_query($db_con, $sql_select);



            ?>










            <div class="sale-slider">
                <div class="top-heading">
                    <h1>New Release <i class="fa-solid fa-angle-right"></i></h1>
                    <div class="slider-arrows">
                        <span class="span-items"><i class="fa-solid fa-angle-left"></i></span>
                        <span class="span-items"><i class="fa-solid fa-angle-right"></i></span>
                    </div>
                </div>
                <section>
                    <?php
                    if (mysqli_num_rows($result_select) > 0) {


                        while ($rows = mysqli_fetch_assoc($result_select)) { ?>

                            <div class="div-item div-item1">
                                <a href="product.php?user_id=<?php echo $rows['game_id']; ?>" class="content-container">
                                    <div class="content-item img-item"><img src="<?php echo $rows['image_link']; ?>" alt=""></div>
                                    <div class="content-item">
                                        <h4>BASE GAME</h4>
                                    </div>
                                    <div class="content-item">
                                        <h3><?php echo $rows['game_name'] ?></h3>
                                    </div>
                                    <div class="content-item">
                                        <div class="original-price discount"><span class="discount-price"><?php echo $rows['price'] ?>$</span></div>
                                    </div>
                                </a>



                            </div>

                        <?php } ?>
                    <?php } else {
                        echo "<h1 class='text-center'>No data Found!</h1>";
                    }      ?>



                </section>

            </div>


            <!---------------------------
    
    
     html code 


-------------------------------->





            <div class="third-container">
                <div class="third-item">
                    <div class="third-img"><img src="https://cdn2.unrealengine.com/egs-spider-man-miles-morales-breaker-1920x1080-d43481b122f0.jpg?h=720&resize=1&w=1280" alt=""></div>
                    <div class="third-content">

                        <h2>Marvel’s Spider-Man: Miles Morales</h2>
                        <p>When a fierce power struggle threatens to destroy his home, Miles must take up the mantle of
                            Spider-Man and own it.</p>
                        <div class="third-price"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>

                    </div>
                </div>
                <div class="third-item">
                    <div class="third-img"><img src="https://cdn2.unrealengine.com/egs-rumbleverse-winter-event-2022-breaker-1920x1080-d80d89c424c4.jpg?h=720&resize=1&w=1280" alt=""></div>
                    <div class="third-content">

                        <h2>Rumbleverse</h2>
                        <p>Snowball Fight LTM is LIVE! Grab the Holiday Demon Pack and ready your throwing arm, the
                            Holiday Update is here!</p>
                        <div class="third-price">Free</div>

                    </div>
                </div>
                <div class="third-item">
                    <div class="third-img"><img src="https://cdn2.unrealengine.com/applejackap-epic-hero-carousel-image-1920x1080-1920x1080-92c4335893ef.jpg?h=720&resize=1&w=1280" alt=""></div>
                    <div class="third-content">

                        <h2>Pre-purchase STAR WARS Jedi: Survivor!</h2>
                        <p>The story of Cal Kestis continues! Pre-purchase now to outfit Cal with the "Jedi Survival"
                            Cosmetic Pack.</p>
                        <div class="third-price"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>

                    </div>
                </div>



            </div>










            <div class="free-games-container">

                <div class="free-games-inner">
                    <div class="free-top">
                        <div class="free-top-left">
                            <i class="fa-solid fa-gift"></i>
                            <h3>Free Games</h3>
                        </div>
                        <div class="free-top-right">
                            <a href="">View More</a>
                        </div>
                    </div>



                    <div class="free-content">

                        <div class="free-content-items">
                            <div class="free-content-img">
                                <img src="https://cdn1.epicgames.com/spt-assets/581b8af82db34e5c98f5dae3ed5b9904/warpips-offer-1pcp0.jpg?h=480&quality=medium&resize=1&w=854" alt="">
                                <div class="upper-layer">Free Now</div>
                            </div>
                            <div class="free-content-detail">
                                <div class="detail-name">Warpips</div>
                                <div class="detail-time">Free Now - Jan 05 at 09:00 PM</div>
                            </div>
                        </div>

                        <div class="free-content-items">
                            <div class="free-content-img">
                                <img src="https://cdn1.epicgames.com/offer/2a14cf8a83b149919a2399504e5686a6/EGS_TheSims4_ElectronicArts_S2_1200x1600-ceadc3bd1e6f885ad64d9f115f51f5c0?h=480&quality=medium&resize=1&w=360" alt="">
                                <div class="upper-layer">Free Now</div>
                            </div>
                            <div class="free-content-detail">
                                <div class="detail-name">The Sims 4</div>
                                <div class="detail-time">Free Now - Jan 05 at 09:00 PM</div>
                            </div>
                        </div>
                        <div class="free-content-items">
                            <div class="free-content-img">
                                <img src="https://cdn1.epicgames.com/offer/9773aa1aa54f4f7b80e44bef04986cea/S9_1200x1600-c1bc7211d9e671d7384e2f0247f0f77a?h=480&quality=medium&resize=1&w=360" alt="">
                                <div class="upper-layer">Free Now</div>
                            </div>
                            <div class="free-content-detail">
                                <div class="detail-name">Rocket League</div>
                                <div class="detail-time">Free Now - Jan 05 at 09:00 PM</div>
                            </div>
                        </div>
                        <div class="free-content-items">
                            <div class="free-content-img">
                                <img src="https://cdn1.epicgames.com/offer/d5241c76f178492ea1540fce45616757/DAY15-carousel-mobile-unwrapped-image1_1200x1600-9716d77667d2a82931c55a4e4130989e?h=854&resize=1&w=640" alt="">
                                <div class="upper-layer">Free Now</div>
                            </div>
                            <div class="free-content-detail">
                                <div class="detail-name">Dishonored - Definitive Edition</div>
                                <div class="detail-time">Free Now - Jan 05 at 09:00 PM</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>














            <div class="top-upcoming-container">
                <div class="vertical-container">
                    <div class="free-top">
                        <div class="free-top-left">
                            <h3>Top Sellers</h3>
                        </div>
                        <div class="free-top-right">
                            <a href="topsellers.php?category_id=1">Vew More</a>
                        </div>
                    </div>


                    <?php


                    //$sql_select = "select * from `game` where game_id=$id";



                    $sql_select2 = "SELECT g.`game_id`, g.`game_name`, g.`image_logo`, g.`price`, g.`game_description`, g.`publisher_id`, g.`developer_id`, g.`release_date`, g.`platform_id`, g.`rating`, i.`image_link`, i.`image_link1`, i.`image_link2`, i.`image_link3`
FROM `game` g
INNER JOIN `image` i ON g.`game_id` = i.`game_id`
WHERE g.`game_id` IN (
    SELECT `game_id`
    FROM `game_categories`
    WHERE `category_id` = 1
)
LIMIT 6
";



                    $result_select2 = mysqli_query($db_con, $sql_select2);

                    if (mysqli_num_rows($result_select2) > 0) {


                    ?>





                        <div class="vertical-flexbox">
                            <?php while ($rows2 = mysqli_fetch_assoc($result_select2)) { ?>



                                <div class="vertical-items">

                                    <div class="vertical-img">
                                        <img src="<?php echo $rows2['image_link'] ?>" alt="">
                                    </div>
                                    <div class="img-detail">
                                        <h3><?php echo $rows2['game_name'] ?></h3>
                                        <div class="third-price">
                                            <!-- <span class="original-1">22$</span> <span class="discount-1">-50%</span>  -->
                                            <span class="discount-price"><?php echo $rows2['price'] ?>$</span>
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>
                        <?php } else {
                        echo "<h1 class='text-center'>No data Found!</h1>";
                    }      ?>

                        <!-- <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                         -->


                        </div>


                </div>

                <div class="vertical-container vertical-lines">
                    <div class="free-top">
                        <div class="free-top-left">
                            <h3>Most Played</h3>
                        </div>
                        <div class="free-top-right">
                            <a href="mostplayed.php?category_id=2">View More</a>
                        </div>
                    </div>




                    <div class="vertical-flexbox">

                        <?php


                        //$sql_select = "select * from `game` where game_id=$id";



                        $sql_select3 = "SELECT g.`game_id`, g.`game_name`, g.`image_logo`, g.`price`, g.`game_description`, g.`publisher_id`, g.`developer_id`, g.`release_date`, g.`platform_id`, g.`rating`, i.`image_link`, i.`image_link1`, i.`image_link2`, i.`image_link3`
FROM `game` g
INNER JOIN `image` i ON g.`game_id` = i.`game_id`
WHERE g.`game_id` IN (
    SELECT `game_id`
    FROM `game_categories`
    WHERE `category_id` = 2
)
LIMIT 6

";



                        $result_select3 = mysqli_query($db_con, $sql_select3);

                        if (mysqli_num_rows($result_select3) > 0) {


                        ?>
                            <?php while ($rows3 = mysqli_fetch_assoc($result_select3)) { ?>


                                <div class="vertical-items">
                                    <div class="vertical-img">
                                        <img src="<?php echo $rows3['image_link'] ?>" alt="">
                                    </div>
                                    <div class="img-detail">
                                        <h3><?php echo $rows3['game_name'] ?></h3>
                                        <div class="third-price">
                                            <!-- <span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span>  -->
                                            <span class="discount-price"><?php echo $rows3['price'] ?>$</span>
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>
                        <?php } else {
                            echo "<h1 class='text-center'>No data Found!</h1>";
                        }      ?>

                        <!-- <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div> -->


                    </div>


                </div>
                <div class="vertical-container">
                    <div class="free-top">
                        <div class="free-top-left">
                            <h3>Top Upcoming Wishlisted</h3>
                        </div>
                        <div class="free-top-right">
                            <a href="upcoming.php?category_id=4">View More</a>
                        </div>
                    </div>




                    <div class="vertical-flexbox">

                        <?php


                        //$sql_select = "select * from `game` where game_id=$id";



                        $sql_select4 = "SELECT g.`game_id`, g.`game_name`, g.`image_logo`, g.`price`, g.`game_description`, g.`publisher_id`, g.`developer_id`, g.`release_date`, g.`platform_id`, g.`rating`, i.`image_link`, i.`image_link1`, i.`image_link2`, i.`image_link3`
FROM `game` g
INNER JOIN `image` i ON g.`game_id` = i.`game_id`
WHERE g.`game_id` IN (
    SELECT `game_id`
    FROM `game_categories`
    WHERE `category_id` = 4
)
LIMIT 6

";



                        $result_select4 = mysqli_query($db_con, $sql_select4);

                        if (mysqli_num_rows($result_select4) > 0) {


                        ?>
                            <?php while ($rows4 = mysqli_fetch_assoc($result_select4)) { ?>


                                <div class="vertical-items">
                                    <div class="vertical-img">
                                        <img src="<?php echo $rows4['image_link'] ?>" alt="">
                                    </div>
                                    <div class="img-detail">
                                        <h3><?php echo $rows4['game_name'] ?></h3>
                                        <div class="third-price">
                                            <!-- <span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> -->
                                            <span class="discount-price"><?php echo $rows4['price'] ?>$</span>
                                        </div>
                                    </div>
                                </div>


                            <?php } ?>
                        <?php } else {
                            echo "<h1 class='text-center'>No data Found!</h1>";
                        }      ?>
                        <!-- <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div> -->


                    </div>


                </div>

            </div>















            <!-- --------------------------------
    
    POPULAR GAMES SLIDER

------------------------------------>




            <div class="sale-slider">
                <div class="top-heading">
                    <h1>Most Popular <i class="fa-solid fa-angle-right"></i></h1>
                    <div class="slider-arrows">
                        <span class="slider-two"><i class="fa-solid fa-angle-left"></i></span>
                        <span class="slider-two"><i class="fa-solid fa-angle-right"></i></span>
                    </div>
                </div>
                <section>



                    <?php


                    // $sql_select = "SELECT * FROM `game` WHERE 1";
                    $sql_select5 = "SELECT g.game_id, g.game_name, g.price, g.game_description, g.publisher_id, g.developer_id, g.release_date, g.platform_id, g.rating, i.image_id, i.image_link, i.image_logo, i.image_link1, i.image_link2, i.image_link3
           FROM game g
           INNER JOIN game_categories gc ON g.game_id = gc.game_id
           INNER JOIN image i ON g.game_id = i.game_id
           WHERE gc.category_id = 5";




                    // if (isset($_POST['submit'])) {

                    //   $search = $_POST['search'];


                    //   $sql_select = "SELECT * FROM `users` where user_id like '%$search%' or user_name like '%$search%' or user_address like '%$search%'";
                    //   $search = '';
                    // }

                    $result_select5 = mysqli_query($db_con, $sql_select5);



                    ?>




                    <?php
                    if (mysqli_num_rows($result_select5) > 0) {


                        while ($rows5 = mysqli_fetch_assoc($result_select5)) { ?>

                            <div class="div-item div-item2">
                                <a href="product.php?user_id=<?php echo $rows5['game_id']; ?>" class="content-container">
                                    <div class="content-item img-item"><img src="<?php echo $rows5['image_link'] ?>" alt=""></div>
                                    <div class="content-item">
                                        <h4>BASE GAME</h4>
                                    </div>
                                    <div class="content-item">
                                        <h3><?php echo $rows5['game_name'] ?></h3>
                                    </div>
                                    <div class="content-item">
                                        <div class="original-price discount">
                                            <!-- <span class="original-1">22$</span> <span class="discount-1">-50%</span>  -->
                                            <span class="discount-price"><?php echo $rows5['price'] ?>$</span>
                                        </div>
                                    </div>
                                </a>



                            </div>



                        <?php } ?>
                    <?php } else {
                        echo "<h1 class='text-center'>No data Found!</h1>";
                    }      ?>

                </section>

            </div>










            <!-- ----------------------------
    
    2nd upcoming vertical games 

---------------------------------->



            <!-- <div class="top-upcoming-container">
                <div class="vertical-container">
                    <div class="free-top">
                        <div class="free-top-left">
                            <h3>New Releases
                            </h3>
                        </div>
                        <div class="free-top-right">
                            <a href="viewmore/topsellers.html">View More</a>
                        </div>
                    </div>




                    <div class="vertical-flexbox">

                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>


                    </div>


                </div>

                <div class="vertical-container vertical-lines">
                    <div class="free-top">
                        <div class="free-top-left">
                            <h3>Top Player Rated
                            </h3>
                        </div>
                        <div class="free-top-right">
                            <a href="viewmore/mostplayed.html">View More</a>
                        </div>
                    </div>




                    <div class="vertical-flexbox">

                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>


                    </div>


                </div>
                <div class="vertical-container">
                    <div class="free-top">
                        <div class="free-top-left">
                            <h3>Coming Soon
                            </h3>
                        </div>
                        <div class="free-top-right">
                            <a href="viewmore/upcoming.html">View More</a>
                        </div>
                    </div>




                    <div class="vertical-flexbox">

                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>
                        <div class="vertical-items">
                            <div class="vertical-img">
                                <img src="https://cdn1.epicgames.com/epic/offer/RDR2PC1227_Epic%20Games_860x1148-860x1148-b4c2210ee0c3c3b843a8de399bfe7f5c.jpg?h=480&resize=1&w=360"
                                    alt="">
                            </div>
                            <div class="img-detail">
                                <h3>God of War</h3>
                                <div class="third-price"><span class="original-1">22$</span> <span
                                        class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </div>


                    </div>


                </div>

            </div>

 -->







            <!-- ----------------------
    
    html third items again

----------------------------->



            <div class="third-container">
                <div class="third-item">
                    <div class="third-img"><img src="https://cdn2.unrealengine.com/egs-touch-type-tale-breaker-1920x1080-6ac22d513b3c.jpg?h=270&quality=medium&resize=1&w=480" alt=""></div>
                    <div class="third-content">

                        <h2>Touch Type Tale</h2>
                        <p>An RTS game with a typing twist! Dazzle your opponents with punishing precision and rapid WPM in the Open Beta.</p>
                        <div class="third-price"><span class="original-1">44$</span> <span class="discount-1">-50%</span> <span class="discount-price">22$</span></div>

                    </div>
                </div>
                <div class="third-item">
                    <div class="third-img"><img src="https://cdn2.unrealengine.com/tetra-preorder-standard-edition-epic-store-landscape-2560x1440-2560x1440-a4256819eeed.jpg?h=270&quality=medium&resize=1&w=480" alt=""></div>
                    <div class="third-content">

                        <h2>Far Cry 6</h2>
                        <p>Ignite a revolution this action-packed shooter. and overthrow a dictator in this action-packed shooter.</p>
                        <div class="third-price">Free</div>

                    </div>
                </div>
                <div class="third-item">
                    <div class="third-img"><img src="https://cdn2.unrealengine.com/egs-disney-dreamlight-valley-festival-friendship-breaker-1248x702-3e5edf43e2e7.jpg?h=270&quality=medium&resize=1&w=480" alt=""></div>
                    <div class="third-content">

                        <h2>Disney Dreamlight Valley: Festival of Friendship</h2>
                        <p>Welcome Mirabel and Olaf to the Valley this action-packed shooter. and discover the mysteries of The Frosted Heights.</p>
                        <div class="third-price"><span class="original-1">30$</span> <span class="discount-1">-50%</span> <span class="discount-price">15$</span></div>

                    </div>
                </div>



            </div>








            <!-- --------------------------------
    
     GAMES with achievements SLIDER

------------------------------------>




            <div class="sale-slider">
                <div class="top-heading">
                    <h1>Games with Achievements <i class="fa-solid fa-angle-right"></i></h1>
                    <div class="slider-arrows">
                        <span class="slider-three"><i class="fa-solid fa-angle-left"></i></span>
                        <span class="slider-three"><i class="fa-solid fa-angle-right"></i></span>
                    </div>
                </div>
                <section>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item3">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>

                </section>

            </div>












            <!-- --------------------------------
    
Recently Upddated GAMES SLIDER

------------------------------------>




            <div class="sale-slider">
                <div class="top-heading">
                    <h1>Recently Updated <i class="fa-solid fa-angle-right"></i></h1>
                    <div class="slider-arrows">
                        <span class="slider-four"><i class="fa-solid fa-angle-left"></i></span>
                        <span class="slider-four"><i class="fa-solid fa-angle-right"></i></span>
                    </div>
                </div>
                <section>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item4">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>


                </section>

            </div>











            <!-- --------------------------------
    
    Now On The Epic Games Store SLIDER

------------------------------------>




            <div class="sale-slider">
                <div class="top-heading">
                    <h1>Now On The Epic Games Store <i class="fa-solid fa-angle-right"></i></h1>
                    <div class="slider-arrows">
                        <span class="slider-five"><i class="fa-solid fa-angle-left"></i></span>
                        <span class="slider-five"><i class="fa-solid fa-angle-right"></i></span>
                    </div>
                </div>
                <section>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>
                    <div class="div-item div-item5">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img src="https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S2_1200x1600-fbdf3cbc2980749091d52751ffabb7b7_1200x1600-fbdf3cbc2980749091d52751ffabb7b7?h=854&resize=1&w=640" alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3>God of War</h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price discount"><span class="original-1">22$</span> <span class="discount-1">-50%</span> <span class="discount-price">11$</span></div>
                            </div>
                        </a>



                    </div>


                </section>

            </div>










            <section>
                <div class="c-container sect-devide">
                    <div class="browse-box ">

                    </div>
                    <div style="width:500px ; margin:150px 0; "> <!--explore out catalog-->
                        <h3 class="para1">Explore Our Catalog</h3>
                        <p class="margin-headline "> Browse by genre, features, price, and more to find your next
                            favorite game.</p>
                        <button class="btn-basic " type="submit">BROWSE ALL</button>
                    </div>
                </div>
            </section>




        </div>




    </main>




    <footer>

        <div class="li-icons">
            <a href="#link"><i class="fa-brands fa-square-facebook fa-2x "></i></a>
            <a href="#link"><i class="fa-brands fa-twitter fa-2x"></i></a>
            <a href="#link"><i class="fa-brands fa-youtube fa-2x"></i></a>
            <a style="float: right; border: 2px solid white; width: 40px; text-align: center; " href="#" id="btnScrollToTop"><i class="fa-sharp fa-solid fa-caret-up fa-2x"></i></a>
        </div>



        <div class="top-li-parent-container">
            <div>
                <h4>Resourses</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Support-A-Creator</a></li>
                        <li> <a href="#link">Distribute on Epic Games</a></li>
                        <li> <a href="#link">Careers</a></li>
                        <li> <a href="#link">Company</a></li>
                    </ul>

                    <ul class="row-links">
                        <li><a href="#link">Fan Art Policy</a></li>
                        <li><a href="#link">UX Research</a></li>
                        <li><a href="#link">Store EULA</a></li>
                    </ul>
                    <ul class="row-links">
                        <li><a href="#link">Online Services</a></li>
                        <li><a href="#link">Community Rules</a></li>
                        <li><a href="#link">Epic Newsroom</a></li>
                    </ul>

                </div>
            </div>

            <div>
                <h4>Made by Epic Games</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Battle Breaker</a></li>
                        <li> <a href="#link">Fortnite</a></li>
                        <li> <a href="#link">Infinity Blade</a></li>
                    </ul>
                    <ul class="row-links">
                        <li> <a href="#link">Robo Recall </a></li>
                        <li> <a href="#link">Shadow Complex</a></li>
                        <li> <a href="#link">Unreal Tournament</a></li>
                    </ul>

                </div>
            </div>




        </div>



        <!--copyrights section -->
        <div>
            <p class="f-text">© 2022, Epic Games, Inc. All rights reserved. Epic, Epic Games, the Epic Games logo,
                Fortnite, the
                Fortnite logo, Unreal, Unreal Engine, the Unreal Engine logo, Unreal Tournament, and the Unreal
                Tournament logo are trademarks or registered trademarks of Epic Games, Inc. in the United States of
                America and elsewhere. Other brands or product names are the trademarks of their respective owners.
                Non-US transactions through Epic Games International, S.à r.l. </p>
        </div>

        <!--Links-->

        <div>
            <ul class="row-links-container row-links">
                <li><a href="#link">Terms of Service</a></li>
                <li><a href="#link">Privacy Policy</a></li>
                <li><a href="#link">Store Refund Policy</a></li>
            </ul>
        </div>

        <div class="footer-logo-container footer-logo">
            <a href="#link"><img src="../images/epic-games-logo.png" alt="Epic Games"></a>
            <a href="#link"><img src="../images/Unreal_Engine.png" alt="Unreal Engine"></a>
        </div>
    </footer>







    <script src="../js/script.js"></script>
</body>

</html>