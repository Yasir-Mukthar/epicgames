<?php
 session_start();

 
 include "../include/dbconnect.php";
 $user_id = $_SESSION['user_id']; 

    
 if (isset($_POST['submit'])) {

    $sql="DELETE FROM `cart` WHERE user_id={$user_id}";
    $result=mysqli_query($db_con, $sql) or die("Query not successful");

 }
        


    
 header("location: cart.php");


 


?>