
<?php
include("secure_session.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Epic Games Store | Download & Play PC Games, Mods, DLC & More – Ahy Games</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/18cde80192.js" crossorigin="anonymous"></script>
</head>

<body>

<header>
        <nav class="navbar">
            <div class="left-nav">
                <div class="logo">

                    <img src="../images/epic-games-logo.png" alt="epic-games-logo" class="logo-img">
                </div>
                <div class="menu-icon">
                    <img src="images/epic-games-logo.png" alt="">
                </div>
                <ul class="menu-ul">
                    <li class="active store" id="one"><a href="home.php">STORE</a>

                    </li>
                    <li><a href="faq.php">FAQ</a> </li>
                    <li><a href="help.php">HELP</a></li>
                    <li><a href="unreal.php">UNREAL ENGINE</a></li>
                </ul>
            </div>
            <div class="right-nav">
                <div class="earth-logo">
                    <i class="fa-solid fa-globe"></i>
                    <ul class="languages">
                        <li><a href="">English</a></li>
                        <li><a href="">Urdu</a></li>
                        <li><a href="">French</a></li>
                        <li><a href="">Arabic</a></li>
                        <li><a href="">Portuguese</a></li>
                        <li><a href="">Dutch</a></li>
                        <li><a href="">Hindi</a></li>
                        <li><a href="">Galician</a></li>
                    </ul>
                </div>
                <div class="sign-in-btn">
                    <i class="fa-solid fa-user"></i>
                    <a href="#" class="namefield"><?php echo strtoupper($_SESSION['user_dname']); ?> </a>
                    <ul class="languages">
                        <li><a href="../include/logout.php">SIGN OUT</a></li>
                       
                    </ul>
                </div>

                <div class="download-btn">
                    <a href="">DOWNLOAD</a>
                </div>
            </div>
        </nav>

    </header>

    <main>
        <div class="fixed-menu">
<div class="fixed-menu-center">
    <h1>Unreal Page</h1>
</div>
        </div>
        <div class="main-content">

        </div>

    </main>
</body>

</html>