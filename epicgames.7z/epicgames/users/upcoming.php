<?php

include("secure_session.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="180">

    <title>Epic Games Store | Download & Play PC Games, Mods, DLC & More – Ahy Games</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/18cde80192.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/viewmore.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/fontawesome.min.css">

</head>

<body>

    <header>
        <nav class="navbar " id="move-top">
            <div class="left-nav">
                <div class="logo">

                    <img src="../images/epic-games-logo.png" alt="epic-games-logo" class="logo-img">
                </div>
                <div class="menu-icon">
                    <img src="images/epic-games-logo.png" alt="">
                </div>
                <ul class="menu-ul">
                    <li class="active store" id="one"><a href="home.php">STORE</a>

                    </li>
                    <li><a href="faq.php">FAQ</a> </li>
                    <li><a href="help.php">HELP</a></li>
                    <li><a href="unreal.php">UNREAL ENGINE</a></li>
                </ul>
            </div>
            <div class="right-nav">
                <div class="earth-logo">
                    <i class="fa-solid fa-globe"></i>
                    <ul class="languages">
                        <li><a href="">English</a></li>
                        <li><a href="">Urdu</a></li>
                        <li><a href="">French</a></li>
                        <li><a href="">Arabic</a></li>
                        <li><a href="">Portuguese</a></li>
                        <li><a href="">Dutch</a></li>
                        <li><a href="">Hindi</a></li>
                        <li><a href="">Galician</a></li>
                    </ul>
                </div>
                <div class="sign-in-btn">
                    <i class="fa-solid fa-user"></i>
                    <a href="#" class="namefield"><?php echo strtoupper($_SESSION['user_dname']); ?> </a>
                    <ul class="languages">
                        <li><a href="../include/logout.php">SIGN OUT</a></li>
                       
                    </ul>
                </div>

                <div class="download-btn">
                    <a href="">DOWNLOAD</a>
                </div>
            </div>
        </nav>

    </header>

    <main>

        <div class="fixed-menu">
            <div class="fixed-menu-center">
                <div class="right-search">
                    <div class="right-inner">

                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input class="input" type="text" placeholder="Search store">

                    </div>
                </div>
                <div class="left-menu">
                    <ul>
                        <li class="whiteColor"><a class="whiteColor" href="">Discover</a></li>
                        <li><a href="">Browse</a></li>
                        <li><a href="">News</a></li>
                    </ul>
                </div>
            </div>
        </div>



        <div class="container">


            <!---------------------------
    
    
    sales slider html code 


-------------------------------->


            <div class="sale-slider">
                <div class="top-heading">
                    <h1>Top Upcoming
                    </h1>

                </div>
                <section>


                
                <?php

                include("../include/dbconnect.php");

                $category_id = $_GET['category_id'];
                //$sql_select = "select * from `game` where game_id=$id";



                $sql_select = "SELECT g.`game_id`, g.`game_name`, g.`image_logo`, g.`price`, g.`game_description`, g.`publisher_id`, g.`developer_id`, g.`release_date`, g.`platform_id`, g.`rating`, i.`image_link`, i.`image_link1`, i.`image_link2`, i.`image_link3`
                FROM `game` g
                INNER JOIN `image` i ON g.`game_id` = i.`game_id`
                WHERE g.`game_id` IN (
                    SELECT `game_id`
                    FROM `game_categories`
                    WHERE `category_id` = $category_id
                )
                
                

";


                $result_select = mysqli_query($db_con, $sql_select);

                if (mysqli_num_rows($result_select) > 0) {


                ?>

                    <?php while ($rows = mysqli_fetch_assoc($result_select)) { ?>




                    <div class="div-item div-item1">
                        <a href="" class="content-container">
                            <div class="content-item img-item"><img
                                    src="<?php echo $rows['image_link'] ?>"
                                    alt=""></div>
                            <div class="content-item">
                                <h4>BASE GAME</h4>
                            </div>
                            <div class="content-item">
                                <h3><?php echo $rows['game_name'] ?></h3>
                            </div>
                            <div class="content-item">
                                <div class="original-price"><span class="discount-price"><?php echo $rows['price'] ?>$</span></div>

                            </div>
                            
                        </a>



                    </div>
                    <?php } ?>
    <?php } else {
                    echo "<h1 class='text-center'>No data Found!</h1>";
                }      ?>

                  


                </section>

            </div>























        </div>




    </main>




    <footer>

        <div class="li-icons">
            <a href="#link"><i class="fa-brands fa-square-facebook fa-2x "></i></a>
            <a href="#link"><i class="fa-brands fa-twitter fa-2x"></i></a>
            <a href="#link"><i class="fa-brands fa-youtube fa-2x"></i></a>
            <a style="float: right; border: 2px solid white; width: 40px; text-align: center; " href="#"
                id="btnScrollToTop"><i class="fa-sharp fa-solid fa-caret-up fa-2x"></i></a>
        </div>



        <div class="top-li-parent-container">
            <div>
                <h4>Resourses</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Support-A-Creator</a></li>
                        <li> <a href="#link">Distribute on Epic Games</a></li>
                        <li> <a href="#link">Careers</a></li>
                        <li> <a href="#link">Company</a></li>
                    </ul>

                    <ul class="row-links">
                        <li><a href="#link">Fan Art Policy</a></li>
                        <li><a href="#link">UX Research</a></li>
                        <li><a href="#link">Store EULA</a></li>
                    </ul>
                    <ul class="row-links">
                        <li><a href="#link">Online Services</a></li>
                        <li><a href="#link">Community Rules</a></li>
                        <li><a href="#link">Epic Newsroom</a></li>
                    </ul>

                </div>
            </div>

            <div>
                <h4>Made by Epic Games</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Battle Breaker</a></li>
                        <li> <a href="#link">Fortnite</a></li>
                        <li> <a href="#link">Infinity Blade</a></li>
                    </ul>
                    <ul class="row-links">
                        <li> <a href="#link">Robo Recall </a></li>
                        <li> <a href="#link">Shadow Complex</a></li>
                        <li> <a href="#link">Unreal Tournament</a></li>
                    </ul>

                </div>
            </div>




        </div>



        <!--copyrights section -->
        <div>
            <p class="f-text">© 2022, Epic Games, Inc. All rights reserved. Epic, Epic Games, the Epic Games logo,
                Fortnite, the
                Fortnite logo, Unreal, Unreal Engine, the Unreal Engine logo, Unreal Tournament, and the Unreal
                Tournament logo are trademarks or registered trademarks of Epic Games, Inc. in the United States of
                America and elsewhere. Other brands or product names are the trademarks of their respective owners.
                Non-US transactions through Epic Games International, S.à r.l. </p>
        </div>

        <!--Links-->

        <div>
            <ul class="row-links-container row-links">
                <li><a href="#link">Terms of Service</a></li>
                <li><a href="#link">Privacy Policy</a></li>
                <li><a href="#link">Store Refund Policy</a></li>
            </ul>
        </div>

        <div class="footer-logo-container footer-logo">
            <a href="#link"><img src="../images/epic-games-logo.png" alt="Epic Games"></a>
            <a href="#link"><img src="../images/Unreal_Engine.png" alt="Unreal Engine"></a>
        </div>
    </footer>







    <script src="js/script.js"></script>
</body>

</html>