<?php
 session_start();


 $game_id = $_GET['game_id'];
 $user_id = $_GET['user_id'];
 $game_price = $_GET['price'];

 include "../include/dbconnect.php";
 
     
     $sqli="INSERT INTO `cart`(`game_id`,`user_id`, `game_price`) VALUES ('$game_id','$user_id','$game_price')";
     $result=mysqli_query($db_con, $sqli);

 
 header("location: cart.php");


 


?>