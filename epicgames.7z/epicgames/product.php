


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="180">

    <title>Epic Games Store | Download & Play PC Games, Mods, DLC & More – Ahy Games</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/18cde80192.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/product.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/fontawesome.min.css">
</head>

<body>

    <header>
        <nav class="navbar " id="move-top">
            <div class="left-nav">
                <div class="logo">

                    <img src="images/epic-games-logo.png" alt="epic-games-logo" class="logo-img">
                </div>

                <ul class="menu-ul">
                    <li class="active store" id="one"><a href="index.php">STORE</a>

                    </li>
                    <li><a href="faq.php">FAQ</a> </li>
                    <li><a href="help.html">HELP</a></li>
                    <li><a href="unreal.html">UNREAL ENGINE</a></li>
                </ul>
            </div>
            <div class="right-nav">
                <div class="earth-logo">
                    <i class="fa-solid fa-globe"></i>
                    <ul class="languages">
                        <li><a href="">English</a></li>
                        <li><a href="">Urdu</a></li>
                        <li><a href="">French</a></li>
                        <li><a href="">Arabic</a></li>
                        <li><a href="">Portuguese</a></li>
                        <li><a href="">Dutch</a></li>
                        <li><a href="">Hindi</a></li>
                        <li><a href="">Galician</a></li>
                    </ul>
                </div>
                <div class="sign-in-btn">
                    <i class="fa-solid fa-user"></i>
                    <a href="signin.php">SIGN IN</a>
                   
                </div>

                <div class="download-btn">
                    <a href="">DOWNLOAD</a>
                </div>
            </div>
        </nav>

    </header>

    <main>

        <div class="fixed-menu">
            <div class="fixed-menu-center">
                <div class="right-search">
                    <div class="right-inner">

                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input style="outline: none; border:none; background-color:#2a2a2a; margin-left :15px; color: #ccc;" class="input" type="text" placeholder="Search store">
                    </div>
                </div>
                <div class="left-menu">
                    <ul>
                        <li class="whiteColor"><a class="whiteColor" href="">Discover</a></li>
                        <li><a href="">Browse</a></li>
                        <li><a href="">News</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="main-section">



                <?php

                include("include/dbconnect.php");

                $id = $_GET['user_id'];
                //$sql_select = "select * from `game` where game_id=$id";



                $sql_select = "SELECT g.game_id, g.game_name,g.image_logo, g.price, g.game_description, pub.name AS publisher_name, dev.name AS developer_name, g.release_date, plat.name AS platform_name, g.rating
FROM game g
JOIN publisher pub ON g.publisher_id = pub.id
JOIN developer dev ON g.developer_id = dev.id
JOIN platform plat ON g.platform_id = plat.id
WHERE g.game_id = $id;

";

                // $sql_select = "SELECT g.game_id, g.game_name, g.price, g.game_description, pub.publisher_name, dev.developer_name, g.release_date, plat.platform_name, g.rating, r.review_id, r.user_name, r.review_text, v.video_id, v.video_link1, v.video_link2, v.video_link3, i.image_id, i.image_link, i.image_logo, i.image_link1, i.image_link2, i.image_link3
                // FROM game g
                // JOIN publisher pub ON g.publisher_id = pub.publisher_id
                // JOIN developer dev ON g.developer_id = dev.developer_id
                // JOIN platform plat ON g.platform_id = plat.platform_id
                // LEFT JOIN user_review r ON g.game_id = r.game_id
                // LEFT JOIN video v ON g.game_id = v.game_id
                // LEFT JOIN image i ON g.game_id = i.game_id;
                // WHERE g.game_id = [$id]";

                $result_select = mysqli_query($db_con, $sql_select);

                if (mysqli_num_rows($result_select) > 0) {


                ?>

                    <?php while ($rows = mysqli_fetch_assoc($result_select)) { ?>

                        <div class="background-video">
                            <h1 class="product-name"><?php echo $rows['game_name'] ?></h1>
                            <div class="product-videos">


                                <!-- second slider -->

                                <div class="col-lg-4">
                                    <div class="carousel">
                                        <?php

$sql_select4 = "
SELECT img.`image_id`, img.`image_link`, img.`image_logo`, img.`image_link1`, img.`image_link2`, img.`image_link3`, vid.`video_id`, vid.`video_link1`, vid.`video_link2`, vid.`video_link3`, vid.`game_id`
FROM `image` AS img
INNER JOIN `video` AS vid ON img.`game_id` = vid.`game_id`
WHERE img.`game_id` = $id;

";


$result_select4 = mysqli_query($db_con, $sql_select4);

if (mysqli_num_rows($result_select4) > 0) {




     while ($rows4 = mysqli_fetch_assoc($result_select4)) { 


?>
                                        <div><iframe src="<?php echo $rows4['video_link1'] ?>" allowfullscreen frameborder="0" name="slider1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>
                                        </div>
                                        <span>
                                            <a href="<?php echo $rows4['video_link1'] ?>" target="slider1"><img src="//img.youtube.com/vi/1TYl3jhfEDA/default.jpg"></a>
                                            <a href="<?php echo $rows4['video_link2'] ?>" target="slider1"><img src="<?php echo $rows4['image_link2'] ?>"></a>
                                            <a href="<?php echo $rows4['video_link3'] ?>" target="slider1"><img src="//img.youtube.com/vi/hSrOpTYKNMw/default.jpg"></a>

                                        </span>

                                        <?php } ?>
    <?php } else {
                    echo "<h1 class='text-center'>No data Found!</h1>";
                }      ?>
                                    </div>
                                </div>

                            </div>

                            <div class="product-description">
                                <p> <?php echo $rows['game_description'] ?></p>
                            </div>
                            <div class="follow-us">
                                <h3>Follow Us</h3>
                                <div class="social-icons">
                                    <a href="https://instagram.com/gamerz_vfx?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-square-facebook"></i></a>
                                    <a href="https://instagram.com/gamerz_vfx?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-instagram"></i></a>
                                    <a href="https://instagram.com/gamerz_vfx?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-youtube"></i></a>
                                    <a href="https://instagram.com/gamerz_vfx?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-twitter"></i></a>
                                    <a href="https://instagram.com/gamerz_vfx?igshid=YmMyMTA2M2Y="><i class="fa-solid fa-earth-americas"></i></a>

                                </div>
                            </div>
                            <div class="product-rating">
                                <h3>Rating</h3>
                                <p><?php echo $rows['rating'] ?></p>
                            </div>
                            <div class="product-reviews">
                                <h3>Reviews</h3>
                                <div class="review-container">
                                    <?php

                                    $sql_select2 = "SELECT `review_id`, `user_name`, `review_text`, `game_id` 
                            FROM `user_review` 
                            WHERE `game_id` = $id
                            LIMIT 3;
                            ";
                                    

$result_select2 = mysqli_query($db_con, $sql_select2);

if (mysqli_num_rows($result_select) > 0) {




     while ($rows2 = mysqli_fetch_assoc($result_select2)) { ?>
                                    


                                    <div class="item">
                                        <h4><?php echo $rows2['user_name'] ?></h4>
                                        <p><?php echo $rows2['review_text'] ?></p>
                                    </div>
                                    <?php } ?>
    <?php } else {
                    echo "<h1 class='text-center'>No review Found!</h1>";
                }      ?>
                                    <!-- <div class="item">
                                <h4>Yasir Mukhtar</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum, voluptate.</p>
                            </div>
                            <div class="item">
                                <h4>Yasir Mukhtar</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum, voluptate.</p>
                            </div> -->
                                </div>
                            </div>
                            <div class="system-specification">
                                <h3>System Specification</h3>
                                <?php
                                $sql_select3 = "SELECT g.game_id, o.os_name, p.processor_name, m.memory_size, s.storage_size, gr.graphics_type
                                FROM game_requirements g
                                JOIN operating_system o ON g.os_id = o.os_id
                                JOIN processor p ON g.processor_id = p.processor_id
                                JOIN memory m ON g.memory_id = m.memory_id
                                JOIN storage s ON g.storage_id = s.storage_id
                                JOIN graphics gr ON g.graphics_id = gr.graphics_id
                                WHERE g.game_id = $id
                                
                        ";

$result_select3 = mysqli_query($db_con, $sql_select3);
if (mysqli_num_rows($result_select3) > 0) {

while ($rows3 = mysqli_fetch_assoc($result_select3)) {
                                ?>
                                <div class="system-container">
                                    <div class="system-items">
                                        <h4>OS</h4>
                                        
                                        <p><?php echo $rows3['os_name'] ?>
                                        </p>
                                    </div>
                                    <div class="system-items">
                                        <h4>Processor</h4>
                                        <p><?php echo $rows3['processor_name'] ?>
                                        </p>
                                    </div>
                                    <div class="system-items">
                                        <h4>Memory</h4>
                                        <p><?php echo $rows3['memory_size'] ?>
                                        </p>
                                    </div>
                                    <div class="system-items">
                                        <h4>Storage</h4>
                                        <p><?php echo $rows3['storage_size'] ?>
                                        </p>
                                    </div>
                                    <div class="system-items">
                                        <h4>Graphics</h4>
                                        <p><?php echo $rows3['graphics_type'] ?>

                                        </p>
                                    </div>
                                </div>
<?php } ?>
    <?php } else {
                    echo "<h1 class='text-center'>No data Found!</h1>";
                }      ?>                            </div>
                        </div>
                        <div class="product-detail">
                            <div class="product-box" id="product-box-id">
                                <div class="product-img">
                                    <img src="<?php echo $rows['image_logo'] ?>" alt="product image">
                                </div>
                                <div class="base-game">
                                    <h4>BASE GAME</h4>
                                </div>
                                <div class="product-price">
                                    <p><?php echo $rows['price'] ?>$</p>
                                </div>
                                <div class="buy-now">
                                    <p>BUY NOW</p>
                                </div>
                                <div class="view-cart">
                                    <p>ADD TO CART</p>
                                </div>
                                <div class="developer-name">
                                    <p>Publisher</p>
                                    <p><?php echo $rows['publisher_name'] ?></p>
                                </div>
                                <div class="developer-name">
                                    <p>Developer</p>
                                    <p><?php echo $rows['developer_name'] ?></p>
                                </div>
                                <div class="release-date">
                                    <p>Release Date</p>
                                    <p><?php echo $rows['release_date'] ?>
                                    </p>
                                </div>
                                <div class="platform">
                                    <p>Platform</p>
                                    <p><?php echo $rows['platform_name'] ?></p>

                                </div>
                            </div>

                        </div>
            </div>



        <?php } ?>
    <?php } else {
                    echo "<h1 class='text-center'>No Data Found!</h1>";
                }      ?>


        </div>


        <div class="container">






        </div>




    </main>




    <footer>

        <div class="li-icons">
            <a href="#link"><i class="fa-brands fa-square-facebook fa-2x "></i></a>
            <a href="#link"><i class="fa-brands fa-twitter fa-2x"></i></a>
            <a href="#link"><i class="fa-brands fa-youtube fa-2x"></i></a>
            <a style="float: right; border: 2px solid white; width: 40px; text-align: center; " href="#" id="btnScrollToTop"><i class="fa-sharp fa-solid fa-caret-up fa-2x"></i></a>
        </div>



        <div class="top-li-parent-container">
            <div>
                <h4>Resourses</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Support-A-Creator</a></li>
                        <li> <a href="#link">Distribute on Epic Games</a></li>
                        <li> <a href="#link">Careers</a></li>
                        <li> <a href="#link">Company</a></li>
                    </ul>

                    <ul class="row-links">
                        <li><a href="#link">Fan Art Policy</a></li>
                        <li><a href="#link">UX Research</a></li>
                        <li><a href="#link">Store EULA</a></li>
                    </ul>
                    <ul class="row-links">
                        <li><a href="#link">Online Services</a></li>
                        <li><a href="#link">Community Rules</a></li>
                        <li><a href="#link">Epic Newsroom</a></li>
                    </ul>

                </div>
            </div>

            <div>
                <h4>Made by Epic Games</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Battle Breaker</a></li>
                        <li> <a href="#link">Fortnite</a></li>
                        <li> <a href="#link">Infinity Blade</a></li>
                    </ul>
                    <ul class="row-links">
                        <li> <a href="#link">Robo Recall </a></li>
                        <li> <a href="#link">Shadow Complex</a></li>
                        <li> <a href="#link">Unreal Tournament</a></li>
                    </ul>

                </div>
            </div>




        </div>



        <!--copyrights section -->
        <div>
            <p class="f-text">© 2022, Epic Games, Inc. All rights reserved. Epic, Epic Games, the Epic Games logo,
                Fortnite, the
                Fortnite logo, Unreal, Unreal Engine, the Unreal Engine logo, Unreal Tournament, and the Unreal
                Tournament logo are trademarks or registered trademarks of Epic Games, Inc. in the United States of
                America and elsewhere. Other brands or product names are the trademarks of their respective owners.
                Non-US transactions through Epic Games International, S.à r.l. </p>
        </div>

        <!--Links-->

        <div>
            <ul class="row-links-container row-links">
                <li><a href="#link">Terms of Service</a></li>
                <li><a href="#link">Privacy Policy</a></li>
                <li><a href="#link">Store Refund Policy</a></li>
            </ul>
        </div>

        <div class="footer-logo-container footer-logo">
            <a href="#link"><img src="images/epic-games-logo.png" alt="Epic Games"></a>
            <a href="#link"><img src="images/Unreal_Engine.png" alt="Unreal Engine"></a>
        </div>
    </footer>







    <script src="js/script.js"></script>
</body>

</html>