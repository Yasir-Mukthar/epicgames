




// Scroll to top button script
const btnScrollToTop = document.getElementById("btnScrollToTop");

btnScrollToTop.addEventListener("click", function () {
	window.scrollTo({
		top: 0,
		left: 0,
		behavior: "smooth"
	});
});











setInterval(changeClass, 10000);
function changeClass() {
	var element1 = document.getElementById("element1");
	var element2 = document.getElementById("element2");
	var element3 = document.getElementById("element3");
	if (element1.matches(".box1")) {
		element1.classList.remove("box1");
		element2.classList.add("box1");
	} else if (element2.matches(".box1")) {
		element2.classList.remove("box1");
		element3.classList.add("box1");
	} else if (element3.matches(".box1")) {
		element3.classList.remove("box1");
		element4.classList.add("box1");
	} else if (element4.matches(".box1")) {
		element4.classList.remove("box1");
		element5.classList.add("box1");
	} else if (element5.matches(".box1")) {
		element5.classList.remove("box1");
		element6.classList.add("box1");
	} else {
		element6.classList.remove("box1");
		element1.classList.add("box1");

	}


}












const dataValues = [

	` 
		<img src="https://cdn2.unrealengine.com/en-holiday-carousel-desktop-1920x1080-aeec8d991d3e.jpg"
                        alt="full back image">

		                    <div class="main-information" >

		<div class="heading">
                   <h4>Epic Game Store</h4>
                   <h3>Holiday Sale</h3>

               </div>
               <span id="span">Festive savings are here!</span>
               <div class="inner-information">
                   <p>Whether you've been naughty or nice, save up to 75% across selected Games and Add-Ons
                       until Jan 5.</p>
               </div>
               <div class="save-btn">
                   <a href="">SAVE NOW</a>
               </div>
			   </div>

			   `
	,
	`
	<img src="https://cdn2.unrealengine.com/en-egs-holidaycoupon2021-store-takeovers-1920x1080-v01-1920x1080-353037d0d13a.jpg?h=1080&resize=1&w=1920"
                        alt="full back image">

		                    <div class="main-information" >

	 <div class="heading">
                   <h4>Epic Games Store</h4>
                   <h3>Holiday Coupon</h3>

               </div>
               <span id="span">Save Big This Holiday Season</span>
               <div class="inner-information">
                   <p>Save 25% when you spend $14.99 or more on New Release or Discounted Games! Offer ends January 5th, 2023 at 11am ET.</p>
               </div>
               <div class="save-btn">
                   <a href="">MORE DETAILS</a>
               </div></div>`
	,

	` 
	<img src="https://cdn2.unrealengine.com/en-free-offers-carousel-desktop-v2-1920x1080-b93c08a48cee.jpg?h=1080&resize=1&w=1920"
                        alt="full back image">

		                    <div class="main-information" >
	
	<div class="heading">
                   <h4>Epic Game Store</h4>
                   <h3>Epic Free Offers</h3>

               </div>
               <span id="span">Free offers to brighten the season</span>
               <div class="inner-information">
                   <p>Whether you've been naughty or nice, save up to 75% across selected Games and Add-Ons
                       until Jan 5.</p>
               </div>
               <div class="save-btn">
                   <a href="">Save Now</a>
               </div></div>`,

	`
	<img src="https://cdn2.unrealengine.com/egs-midnight-suns-carousel-desktop-accolade-v2-en-1248x702-7b27daadec86.jpg?h=1080&resize=1&w=1920"
                        alt="full back image">

		                    <div class="main-information" >
	
	
	<div class="heading">
                   <h4>Marvel's</h4>
                   <h3>Midnight Suns</h3>

               </div>
               <span id="span">Out Now</span>
               <div class="inner-information">
                   <p>Unleash the Super Hero within in this all-new tactical RPG!, save up to 95%</p>
               </div>
               <div class="save-btn">
                   <a href="">BUY NOW</a>
               </div></div>`,
	`
	<img src="https://cdn2.unrealengine.com/egs-need-for-speed-unbount-palace-edition-carousel-desktop-1248x702-40d5e46ab1d1.jpg?h=1080&resize=1&w=1920"
                        alt="full back image">

		                    <div class="main-information" >
	
	<div class="heading">
                   <h4></h4>
                   <h3>Need For Speed</h3>

               </div>
               <span id="span">Festive savings are here!</span>
               <div class="inner-information">
                   <p>Whether you've been naughty or nice, save up to 75% across selected Games and Add-Ons
                       until Jan 5.</p>
               </div>
               <div class="save-btn">
                   <a href="">Save Now</a>
               </div> </div>`,

	`
	<img src="https://cdn2.unrealengine.com/egs-callisto-protocol-carousel-desktop-1248x702-96d958a51128.jpg?h=1080&resize=1&w=1920"
                        alt="full back image">

		                    <div class="main-information" >
	
	<div class="heading">
                   <h4>The</h4>
                   <h3>Callisto Protocol</h3>

               </div>
               <span id="span">Festive savings are here!</span>
               <div class="inner-information">
                   <p>Whether you've been naughty or nice, save up to 55% across selected Games and Add-Ons
                       until Jan 5.</p>
               </div>
               <div class="save-btn">
                   <a href="">Save Now</a>
               </div></div>`



];
var arrValue = 1;

setInterval(changeContent, 10000);

function changeContent() {

	var element = document.getElementById("mainInformationID");
	element.innerHTML = dataValues[arrValue];

	arrValue++;
	if (arrValue == 6) {
		arrValue = 0;
	}
}






































var span = document.getElementsByClassName('span-items');
var slider_two = document.getElementsByClassName('slider-two');
var slider_three = document.getElementsByClassName('slider-three');
var slider_four = document.getElementsByClassName('slider-four');
var slider_five = document.getElementsByClassName('slider-five');

var div = document.getElementsByClassName('div-item1');
var div2 = document.getElementsByClassName('div-item2');
var div3 = document.getElementsByClassName('div-item3');
var div4 = document.getElementsByClassName('div-item4');
var div5 = document.getElementsByClassName('div-item5');
var l = 0;
span[1].onclick = () => {
	l++;
	for (var i of div) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		// if (l==4) {i.style.left = "-2900px";}
		if (l > 4) { l = 4; }
	}
}
span[0].onclick = () => {
	l--;
	for (var i of div) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		if (l < 0) { l = 0; }
	}
}








slider_two[1].onclick = () => {
	l++;
	for (var i of div2) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		// if (l==4) {i.style.left = "-2900px";}
		if (l > 4) { l = 4; }
	}
}
slider_two[0].onclick = () => {
	l--;
	for (var i of div2) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		if (l < 0) { l = 0; }
	}
}







slider_three[1].onclick = () => {
	l++;
	for (var i of div3) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		// if (l==4) {i.style.left = "-2900px";}
		if (l > 4) { l = 4; }
	}
}
slider_three[0].onclick = () => {
	l--;
	for (var i of div3) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		if (l < 0) { l = 0; }
	}
}






slider_four[1].onclick = () => {
	l++;
	for (var i of div4) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		// if (l==4) {i.style.left = "-2900px";}
		if (l > 4) { l = 4; }
	}
}
slider_four[0].onclick = () => {
	l--;
	for (var i of div4) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		if (l < 0) { l = 0; }
	}
}





slider_five[1].onclick = () => {
	l++;
	for (var i of div5) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		// if (l==4) {i.style.left = "-2900px";}
		if (l > 4) { l = 4; }
	}
}
slider_five[0].onclick = () => {
	l--;
	for (var i of div5) {
		if (l == 0) { i.style.left = "0px"; }
		if (l == 1) { i.style.left = "-740px"; }
		if (l == 2) { i.style.left = "-1480px"; }
		if (l == 3) { i.style.left = "-2200px"; }
		if (l < 0) { l = 0; }
	}
}









