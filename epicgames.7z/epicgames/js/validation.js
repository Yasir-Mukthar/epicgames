
function validateForm() {
  var form = document.getElementById("dform");
  var isValid = true;
  var isAboveFilled = false;

  var fname = document.getElementById("fname");
  var lname = document.getElementById("lname");
  var dname = document.getElementById("dname");
  var demail = document.getElementById("demail");
  var dpassword = document.getElementById("dpassword");
  var dnews = document.getElementById("dnews");
  var dpolicy = document.getElementById("dpolicy");

  // validate first name
  if (fname.value.length < 2 || fname.value.length > 20) {
    //alert("First name must be between 2 and 20 characters long.");
    fname.style.border = "1px solid red";
    isValid = false;
  } else {
    fname.style.border = "1px solid #ccc";
  }

  // validate last name
  if (lname.value.length < 2 || lname.value.length > 20) {
    //alert("Last name must be between 2 and 20 characters long.");
    lname.style.border = "1px solid red";
    isValid = false;
  } else {
    lname.style.border = "1px solid #ccc";
  }

  // validate display name
  if (dname.value.length < 4 || dname.value.length > 20) {
   // alert("Display name must be between 4 and 20 characters long.");
    dname.style.border = "1px solid red";
    isValid = false;
  } else {
    dname.style.border = "1px solid #ccc";
  }

  // validate email
  var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  if (!emailPattern.test(demail.value)) {
   // alert("Invalid email address.");
    demail.style.border = "1px solid red";
    isValid = false;
  } else {
    demail.style.border = "1px solid #ccc";
  }

// validate password
var passwordPattern = /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
if (!passwordPattern.test(dpassword.value)) {
  //alert("Password must be at least 8 characters long, and must contain at least one lowercase letter, one uppercase letter, and one digit.");
  dpassword.style.border = "1px solid red";
  isValid = false;
} else {
  dpassword.style.border = "1px solid #ccc";
  isAboveFilled=true;
}

 

  if (!dpolicy.checked && isAboveFilled) {
    alert("You must agree to terms and services.");
    dpolicy.style.border = "1px solid red";
    isValid = false;
  } else {
    dpolicy.style.border = "1px solid #ccc";
  }



    if(isValid){
      return true;
    }else{
      //alert("ddd");
      return false;
    }


  
  }

  
    




