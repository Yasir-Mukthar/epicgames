
  
function validateFormSignin() {
    var isValid1 = true;
    var isAboveFilled1 = false;
  
  
    var demail1 = document.getElementById("demail");
    var dpassword1 = document.getElementById("dpassword");
  
  
    
  
    // validate email
    var emailPattern1 = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailPattern1.test(demail1.value)) {
     // alert("Invalid email address.");
      demail1.style.border = "1px solid red";
      isValid1 = false;
    } else {
      demail1.style.border = "1px solid #ccc";
    }
  
    // validate password
    var passwordPattern1 = /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    if (!passwordPattern1.test(dpassword1.value)) {
      //alert("Password must be at least 8 characters long, and must contain at least one lowercase letter, one uppercase letter, and one digit.");
      dpassword1.style.border = "1px solid red";
      isValid1 = false;
    } else {
      dpassword1.style.border = "1px solid #ccc";
      isAboveFilled1=true;
    }
  
   
  
  
      if(isValid1){
        return true;
      }else{
        //alert("ddd");
        return false;
      }
  
  
    
    }