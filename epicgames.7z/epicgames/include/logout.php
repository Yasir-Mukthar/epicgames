<?php
    session_start();
    unset($_SESSION["user_dname"]);
    unset($_SESSION["login"]);
    session_destroy();
    header("Location:../signin.php");
?>