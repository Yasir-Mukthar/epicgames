<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "epicgam";

$db_con = mysqli_connect($server, $username, $password, $database);
if ($db_con){
     
 }
 else{
    die("Error". mysqli_connect_error());
}

?>