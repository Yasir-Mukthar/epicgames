

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Epic Games Store | Download & Play PC Games, Mods, DLC & More – Ahy Games</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/faq.css">
    <script src="https://kit.fontawesome.com/18cde80192.js" crossorigin="anonymous"></script>
</head>

<body>

    <header>
        <nav class="navbar">
            <div class="left-nav">
                <div class="logo">

                    <img src="images/epic-games-logo.png" alt="epic-games-logo" class="logo-img">
                </div>
                <div class="menu-icon">
                    <img src="images/epic-games-logo.png" alt="">
                </div>
                <ul class="menu-ul">
                    <li class="active store"><a href="index.php">STORE</a>

                    </li>
                    <li id="one"><a href="faq.php">FAQ</a> </li>
                    <li><a href="help.html">HELP</a></li>
                    <li><a href="unreal.html">UNREAL ENGINE</a></li>
                </ul>
            </div>
            <div class="right-nav">
                <div class="earth-logo">
                    <i class="fa-solid fa-globe"></i>
                    <ul class="languages">
                        <li><a href="">English</a></li>
                        <li><a href="">Urdu</a></li>
                        <li><a href="">French</a></li>
                        <li><a href="">Arabic</a></li>
                        <li><a href="">Portuguese</a></li>
                        <li><a href="">Dutch</a></li>
                        <li><a href="">Hindi</a></li>
                        <li><a href="">Galician</a></li>
                    </ul>
                </div>
                <div class="sign-in-btn">
                    <i class="fa-solid fa-user"></i>
                    <a href="signin.php">SIGN IN</a>
                </div>

                <div class="download-btn">
                    <a href="">DOWNLOAD</a>
                </div>
            </div>
        </nav>

    </header>

    <main class="faq-container">
        <h2>FREQUENTLY ASKED QUESTIONS
        </h2>
        <div class="questions-container">
            <h3>Which platforms does the Epic Games Store support?
            </h3>
            <p>The Epic Games Store currently offers PC and Mac support. You can check platform compatibility for
                individual titles by referring to the "Specifications" section of any product page.
            </p>
        </div>
        <div class="questions-container">
            <h3>What are the future plans for the Epic Games Store?

            </h3>
            <p>You can find upcoming features, developer updates, and major known issues on our Epic Games Store Roadmap on Trello. We’ll also share significant updates with you on our news feed and social media pages such as Facebook, Twitter, Instagram, and YouTube. 

            </p>
        </div>

        <div class="questions-container">
            <h3>Why does the Epic Games Store make exclusivity deals?

            </h3>
            <p>Exclusives are a part of the growth of many successful platforms for games and for other forms of digital entertainment, such as streaming video and music.

                Epic works in partnership with developers and publishers to offer games exclusively on the store. In exchange for exclusivity, Epic provides them with financial support for development and marketing, which enables them to build more polished games with significantly less uncertainty for the creators. In addition, creators will earn 88% of all the revenue from their game
            </p>
        </div>

        <div class="questions-container">
            <h3>What is the Support-A-Creator program? 

            </h3>
            <p>The Support-A-Creator program enables content Creators to earn money from games in the Epic Games Store by using Creator Links and Creator Tags. Learn more about the Support-A-Creator program here. 


            </p>
        </div>

        <div class="questions-container">
            <h3>What’s this about free games?

            </h3>
            <p>Epic will be offering a new free game available each week. When you claim a free game, it’s yours to keep - even after the game is no longer available to new customers for free.

            </p>
        </div>

        <div class="questions-container">
            <h3>I claimed a free game but don’t see it on my account now, why?

            </h3>
            <p>Once you claim a free game, it’s yours to keep. If you come back later and don’t see it in your account, please check to see if you have multiple accounts. If you created an Epic account using an @gmail.com email address, log in to it directly using your Gmail password; using the Google login button will create a distinct account even if it’s tied to the same @gmail.com email address. And check to see if you have both a console-linked account (logging in via PlayStation, Xbox, or Nintendo account) and a separate Epic account. If you still encounter issues, please contact player support here.

            </p>
        </div>

        <div class="questions-container">
            <h3>Can I try a game before I buy it?

            </h3>
            <p>Some publishers occasionally offer demos or free trial periods for certain non-free games from time to time (for example, a Free Weekend trial). During a free trial period, you can download and play a trial version of the game before you decide to purchase, but you can no longer access the game when the trial period ends.

            </p>
        </div>

        <div class="questions-container">
            <h3>When are products eligible for a refund?

            </h3>
            <p>Games and products are eligible for refund within 14 days of purchase if they are marked as “refundable” or “self-refundable”. However, you must have less than 2 hours of runtime on record. Products that include virtual currency or other consumables and products or games that are marked as “non-refundable” are not eligible for refund.

                You will not be eligible for refunds for games or products from which you have been banned or for which you have otherwise violated the Terms of Service. In addition, you may not be eligible for refunds if Epic determines that you are abusing the refund policy. Learn more about our refund policy here.
            </p>
        </div>

        <div class="questions-container">
            <h3>How do I contact support?

            </h3>
            <p>You can contact our support team here. We also recommend browsing our support center articles, which may help answer questions or resolve issues.

            </p>
        </div>

        <div class="questions-container">
            <h3>How do I make my Epic Games account secure?

            </h3>
            <p>The Epic account system powers Fortnite, Rocket League, Fall Guys, the Epic Games Store, and Unreal Engine. If you use the same email address and password on Epic as you used on another site which has been compromised, then your account is vulnerable to attack. To secure your Epic account, use a unique password, and enable multi-factor authentication. You can learn more about the measures we take to protect your account and what you can do to stay safe here.

            </p>
        </div>

        <div class="questions-container">
            <h3>What languages does the Epic Games Store support?

            </h3>
            <p>The Epic Games Store currently supports English, Arabic, German, Spanish (Spain), Spanish (Latin America), French, Italian, Japanese, Korean, Polish, Portuguese, Russian, Thai, Turkish, Simplified Chinese, and Traditional Chinese. In-game language support varies per game, as provided by the developer; check each game’s store page for language availability.

            </p>
        </div>

        <div class="questions-container">
            <h3>Does the Epic Games Store support regional pricing?

            </h3>
            <p>Yes, we do support regional pricing in more than 190 countries and over 30 territories. We also provide suggested regional prices for developers based on regional exchange rates, local purchasing power, and industry experience.

            </p>
        </div>

        <div class="questions-container">
            <h3>Which payment methods are supported?

            </h3>
            <p>The Epic Games Store supports credit cards, PayPal, and a variety of alternative payment methods. Below is a list of the alternative payment methods we currently support. Methods carrying additional payment processing fees are marked with an *asterisk.

            </p>
        </div>

        <div class="questions-container">
            <h3>Where is the Epic Games store available?

            </h3>
            <p>The Epic Games Store is available to players in most countries in the world except where prohibited by US law, such as North Korea and Iran. Certain regions may have additional legal requirements that developers may need to implement in their games in order to be compliant and to be distributed there.

            </p>
        </div>

        <div class="questions-container">
            <h3>Which currencies do you accept and in which currencies do you display prices?

            </h3>
            <p>The Epic Games Store currently accepts 43 currencies (USD, EUR, GBP, PLN, BRL, UAH, RUB, KRW, JPY, TRY, AUD, CAD, DKK, NOK, SEK, CZK, ILS, CHF, MXN, PEN, HUF, CLP, SAR, AED, RON, NZD, ZAR, INR, COP, CSC, UYU, HKD, IDR, MYR, PHP, SGD, THB, VND, KZT, QAR, BGN, TWD, CNY). We’re working to bring more currencies online.

            </p>
        </div>

        
    </main>

    <footer>

        <div class="li-icons">
            <a href="#link"><i class="fa-brands fa-square-facebook fa-2x "></i></a>
            <a href="#link"><i class="fa-brands fa-twitter fa-2x"></i></a>
            <a href="#link"><i class="fa-brands fa-youtube fa-2x"></i></a>
            <a style="float: right; border: 2px solid white; width: 40px; text-align: center; " href="#"
                id="btnScrollToTop"><i class="fa-sharp fa-solid fa-caret-up fa-2x"></i></a>
        </div>



        <div class="top-li-parent-container">
            <div>
                <h4>Resourses</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Support-A-Creator</a></li>
                        <li> <a href="#link">Distribute on Epic Games</a></li>
                        <li> <a href="#link">Careers</a></li>
                        <li> <a href="#link">Company</a></li>
                    </ul>

                    <ul class="row-links">
                        <li><a href="#link">Fan Art Policy</a></li>
                        <li><a href="#link">UX Research</a></li>
                        <li><a href="#link">Store EULA</a></li>
                    </ul>
                    <ul class="row-links">
                        <li><a href="#link">Online Services</a></li>
                        <li><a href="#link">Community Rules</a></li>
                        <li><a href="#link">Epic Newsroom</a></li>
                    </ul>

                </div>
            </div>

            <div>
                <h4>Made by Epic Games</h4>
                <div class="div-list ">
                    <ul class="row-links">
                        <li> <a href="#link">Battle Breaker</a></li>
                        <li> <a href="#link">Fortnite</a></li>
                        <li> <a href="#link">Infinity Blade</a></li>
                    </ul>
                    <ul class="row-links">
                        <li> <a href="#link">Robo Recall </a></li>
                        <li> <a href="#link">Shadow Complex</a></li>
                        <li> <a href="#link">Unreal Tournament</a></li>
                    </ul>

                </div>
            </div>




        </div>



        <!--copyrights section -->
        <div>
            <p class="f-text">© 2022, Epic Games, Inc. All rights reserved. Epic, Epic Games, the Epic Games logo,
                Fortnite, the
                Fortnite logo, Unreal, Unreal Engine, the Unreal Engine logo, Unreal Tournament, and the Unreal
                Tournament logo are trademarks or registered trademarks of Epic Games, Inc. in the United States of
                America and elsewhere. Other brands or product names are the trademarks of their respective owners.
                Non-US transactions through Epic Games International, S.à r.l. </p>
        </div>

        <!--Links-->

        <div>
            <ul class="row-links-container row-links">
                <li><a href="#link">Terms of Service</a></li>
                <li><a href="#link">Privacy Policy</a></li>
                <li><a href="#link">Store Refund Policy</a></li>
            </ul>
        </div>

        <div class="footer-logo-container footer-logo">
            <a href="#link"><img src="images/epic-games-logo.png" alt="Epic Games"></a>
            <a href="#link"><img src="images/Unreal_Engine.png" alt="Unreal Engine"></a>
        </div>
    </footer>


</body>

</html>